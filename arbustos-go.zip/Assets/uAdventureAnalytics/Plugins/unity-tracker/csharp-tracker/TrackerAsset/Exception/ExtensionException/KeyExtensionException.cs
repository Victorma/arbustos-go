using System;

namespace AssetPackage.Exceptions
{
    public class KeyExtensionException : ExtensionException{
        public KeyExtensionException(string message) : base(message){
        }
    }
}