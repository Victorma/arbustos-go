﻿using System.Collections;
using System.Collections.Generic;
using uAdventure.Runner;

public class PreviewManager : Singleton<PreviewManager>
{
	public bool InPreviewMode { get; set; }
}