﻿namespace uAdventure.Editor
{
    public interface ProjectConfigDataConsumer
    {
        void updateData();
    }
}