﻿using UnityEngine;
using System.Collections;

using uAdventure.Core;

namespace uAdventure.Editor
{
    public class AdaptationProfilesDataControl// : DataControl
    {
    }
}