using UnityEngine;

public class BaseSetting
{
    [HideInInspector]
    public bool showContent;
}