﻿using System;
using System.Collections.Generic;
using UnityEngine;


namespace uAdventure.Geo
{
    public class RadialTransformManager : ITransformManager
    {
        public ExtElemReference Context
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public Transform ExtElemReferenceTransform
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public void Configure(Dictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
